{
    'name': 'AzSmart NKA Integration',
    'version': '18.0.1.0',
    'category': 'Sales/Point of Sale',
    'summary': 'AzSmart NKA (SmartOne) v3.9 API İnteqrasiyası',
    'description': 'Bu modul Odoo POS satışlarının AzSmart fiskal cihazlarına inteqrasiyasını təmin edir.',
    'author': 'Sadiq Abışov',
    'depends': ['point_of_sale', 'web'],
    'data': [
        'views/pos_config_view.xml',
    ],
    'assets': {
        'point_of_sale._assets_pos': [
            'pos_azsmart_fiskal/static/src/js/azsmart_print.js',
        ],
    },
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}