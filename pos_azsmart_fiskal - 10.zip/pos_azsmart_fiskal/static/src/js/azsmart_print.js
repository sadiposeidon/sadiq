/** @odoo-module **/

import { Order } from "@point_of_sale/app/store/models";
import { PaymentScreen } from "@point_of_sale/app/screens/payment_screen/payment_screen";
import { patch } from "@web/core/utils/patch";

// 1. SHA-1 İmzalama funksiyası
async function generateSignature(data, merchantId) {
    const msgUint8 = new TextEncoder().encode(data + merchantId);
    const hashBuffer = await crypto.subtle.digest('SHA-1', msgUint8);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hexHash = hashArray.map(b => b.toString(16).padStart(2, '0')).join('').toLowerCase();
    // Hex string-i base64-ə çeviririk (API-nin tələbinə uyğun)
    return btoa(hexHash);
}

// 2. Order modelini patch edirik (Məlumatların saxlanması üçün)
patch(Order.prototype, {
    setup() {
        super.setup(...arguments);
        this.azsmart_fiscal_id = this.azsmart_fiscal_id || "";
        this.azsmart_check_no = this.azsmart_check_no || "";
        this.azsmart_qr_url = this.azsmart_qr_url || "";
        this.azsmart_document_id = this.azsmart_document_id || ""; 
    },
    export_as_JSON() {
        const json = super.export_as_JSON(...arguments);
        json.azsmart_fiscal_id = this.azsmart_fiscal_id;
        json.azsmart_check_no = this.azsmart_check_no;
        json.azsmart_qr_url = this.azsmart_qr_url;
        json.azsmart_document_id = this.azsmart_document_id;
        return json;
    },
    init_from_JSON(json) {
        super.init_from_JSON(...arguments);
        this.azsmart_fiscal_id = json.azsmart_fiscal_id || "";
        this.azsmart_check_no = json.azsmart_check_no || "";
        this.azsmart_qr_url = json.azsmart_qr_url || "";
        this.azsmart_document_id = json.azsmart_document_id || "";
    }
});

// 3. Ödəniş Ekranını patch edirik
patch(PaymentScreen.prototype, {
    async validateOrder(forceValidate) {
        const order = this.currentOrder;
        const config = this.pos.config;

        // Əgər AzSmart aktivdirsə və IP qeyd olunubsa proses başlasın
        if (config.azsmart_active && config.azsmart_device_ip) {
            try {
                const orderLines = order.lines || [];
                const paymentLines = order.payment_ids || [];

                // Məhsulları API formatına salırıq
                const fiscalItems = orderLines.map(line => {
                    return {
                        itemId: line.product.id.toString(),
                        itemName: line.product.display_name || line.product.name,
                        itemQty: Math.round(line.qty * 1000), 
                        itemAmount: Math.round(line.price_subtotal_incl * 100), // Qəpiklə
                        discount: Math.round((line.discount || 0) * 100),
                        itemTaxes: [{ taxName: "EDV", taxPrc: 1800 }] // Standart 18%
                    };
                });

                let cashAmount = 0;
                let cashlessAmount = 0;

                paymentLines.forEach(payment => {
                    if (payment.payment_method.type === 'cash') {
                        cashAmount += payment.amount;
                    } else {
                        cashlessAmount += payment.amount;
                    }
                });

                const fiscalData = {
                    docNumber: order.name,
                    employeeName: this.pos.get_cashier().name || "Administrator",
                    amount: Math.round(order.get_total_with_tax() * 100),
                    currency: "AZN",
                    items: fiscalItems,
                    payments: {
                        cashAmount: Math.round(cashAmount * 100),
                        cashlessAmount: Math.round(cashlessAmount * 100),
                        otherAmount: 0
                    }
                };

                // UTF-8 dəstəyi ilə Base64 encode
                const jsonStr = JSON.stringify(fiscalData);
                const encodedData = btoa(unescape(encodeURIComponent(jsonStr)));
                const signature = await generateSignature(encodedData, config.azsmart_merchant_id || "T12345X");

                const url = `http://${config.azsmart_device_ip}:${config.azsmart_device_port || '8008'}/sale`;
                
                const response = await fetch(url, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `data=${encodeURIComponent(encodedData)}&sign=${encodeURIComponent(signature)}`
                });

                if (response.ok) {
                    const result = await response.json();
                    if (result.status === "success") {
                        // Fiskal məlumatları order obyektinə yazırıq
                        order.azsmart_fiscal_id = result.fiscalId;
                        order.azsmart_check_no = result.checkNumber;
                        order.azsmart_qr_url = result.qrCodeUrl;
                        order.azsmart_document_id = result.documentID || result.fiscalId;

                        // API-nin daxili emalı üçün 2 saniyəlik gecikmə ilə status yoxlanışı
                        setTimeout(async () => {
                            await this._checkAzSmartStatus(order.azsmart_document_id);
                        }, 2000);
                    }
                }
            } catch (err) {
                console.error(">>> AzSmart Satış Xətası:", err);
                // Qeyd: Xəta olduqda satışın Odoo-da davam etməsinə icazə verilir. 
                // Əgər bloklamaq istəyirsinizsə, burada 'return' edə bilərsiniz.
            }
        }
        return await super.validateOrder(...arguments);
    },

    // Köməkçi metod: Status yoxlama
    async _checkAzSmartStatus(documentID) {
        const config = this.pos.config;
        const statusData = { documentID: documentID };
        const sEncoded = btoa(JSON.stringify(statusData));
        const sSig = await generateSignature(sEncoded, config.azsmart_merchant_id || "T12345X");
        
        try {
            const statusUrl = `http://${config.azsmart_device_ip}:${config.azsmart_device_port || '8008'}/check_status`;
            await fetch(statusUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `data=${encodeURIComponent(sEncoded)}&sign=${encodeURIComponent(sSig)}`
            });
        } catch (e) {
            console.error("Status yoxlanışında xəta:", e);
        }
    },

    // Yeni: Refund (Geri qaytarma/Ləğv) funksiyası
    async cancelAzSmartFiscal(order) {
        const config = this.pos.config;
        if (!order.azsmart_document_id || !config.azsmart_active) return;

        const refundData = {
            documentID: order.azsmart_document_id,
            amount: Math.round(order.get_total_with_tax() * 100),
            cashierName: this.pos.get_cashier().name || "Admin"
        };

        const rEncoded = btoa(JSON.stringify(refundData));
        const rSig = await generateSignature(rEncoded, config.azsmart_merchant_id || "T12345X");

        try {
            const url = `http://${config.azsmart_device_ip}:${config.azsmart_device_port || '8008'}/refund`;
            await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `data=${encodeURIComponent(rEncoded)}&sign=${encodeURIComponent(rSig)}`
            });
            console.log(">>> AzSmart: Çek ləğv edildi (Refund)");
        } catch (err) {
            console.error(">>> AzSmart Ləğv Xətası:", err);
        }
    }
});