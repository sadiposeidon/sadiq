import os
from flask import Flask, request, jsonify
from flask_cors import CORS
import json
import base64
import hashlib
from urllib.parse import unquote
from datetime import datetime

app = Flask(__name__)
CORS(app)

# Tənzimləmələr
MERCHANT_ID = "T12345X" 
PORT = 8008

# Rəng Kodları
G = "\033[1;32m"  # Yaşıl (Açarlar üçün)
B = "\033[1;34m"  # Mavi (Dəyərlər üçün)
W = "\033[1;37m"  # Ağ (Başlıqlar üçün)
R = "\033[1;31m"  # Qırmızı (Xətalar üçün)
RESET = "\033[0m"

def setup_terminal():
    if os.name == "nt": 
        os.system("cls")
        os.system("color 0A")
    else:
        os.system("clear")
    print(f"{G}")

def print_tree(data, indent=0):
    """Açarları Yaşıl, Dəyərləri Mavi göstərən iyerarxik struktur"""
    prefix = "    " * indent
    if isinstance(data, dict):
        items = list(data.items())
        for i, (key, value) in enumerate(items):
            is_last = (i == len(items) - 1)
            connector = "└── " if is_last else "├── "
            if isinstance(value, (dict, list)):
                print(f"{prefix}{connector}{G}{key}{RESET}")
                print_tree(value, indent + 1)
            else:
                print(f"{prefix}{connector}{G}{key}: {B}{value}{RESET}")
    elif isinstance(data, list):
        for i, item in enumerate(data):
            is_last = (i == len(data) - 1)
            connector = "└── " if is_last else "├── "
            print(f"{prefix}{connector}{W}[Element {i+1}]{RESET}")
            print_tree(item, indent + 1)

def verify_and_decode(request_form):
    data_raw = request_form.get('data', '')
    sign_from_odoo = request_form.get('sign', '')
    raw_string = (data_raw + MERCHANT_ID).encode('utf-8')
    sha1_hash = hashlib.sha1(raw_string).hexdigest().lower()
    expected_sign = base64.b64encode(sha1_hash.encode('utf-8')).decode('utf-8')
    
    try:
        decoded_bytes = base64.b64decode(data_raw)
        decoded_str = unquote(decoded_bytes.decode('utf-8'))
        json_data = json.loads(decoded_str)
    except:
        json_data = {"error": "Deşifrə xətası"}
    return (sign_from_odoo == expected_sign), json_data

def print_header(title):
    print(f"\n{W}╔" + "═"*60 + "╗")
    print(f"║ {title.center(58)} ║")
    print("╠" + "═"*60 + "╣" + f"{RESET}")

def print_footer():
    print(f"{W}╚" + "═"*60 + "╝" + f"{RESET}")

@app.route('/sale', methods=['POST'])
def sale():
    is_valid, json_data = verify_and_decode(request.form)
    print_header("SATIŞ ƏMƏLİYYATI (SALE)")
    print(f"{G}║ {W}Zaman:  {B}{datetime.now().strftime('%H:%M:%S')}{' '*(41)} {W}║")
    print(f"{G}║ {W}İmza:   {B}{'✅ DOGRU' if is_valid else '❌ YALNIS'}{' '*(42)} {W}║")
    print(f"{W}╠" + "═"*60 + "╣")
    print_tree(json_data)
    print_footer()
    return jsonify({
        "status": "success", "documentID": "DOC-"+datetime.now().strftime("%H%M%S"),
        "fiscalId": "AZ-SALE-TEST", "checkNumber": "552",
        "qrCodeUrl": "https://monitoring.e-kassa.az/"
    })

@app.route('/refund', methods=['POST'])
def refund():
    is_valid, json_data = verify_and_decode(request.form)
    print_header("GERİ QAYTARMA (REFUND)")
    print(f"{G}║ {W}Zaman:  {B}{datetime.now().strftime('%H:%M:%S')}{' '*(41)} {W}║")
    print(f"{W}╠" + "═"*60 + "╣")
    print_tree(json_data)
    print_footer()
    return jsonify({"status": "success", "documentID": "REF-123", "fiscalId": "REF-AZ-001"})

# @app.route('/get_info', methods=['POST'])
# def get_info():
#     is_valid, json_data = verify_and_decode(request.form)
    
#     print_header("CİHAZ MƏLUMATLARININ ALINMASI (GET_INFO)")
    
#     if is_valid:
#         print(f"{G}║ {W}Status:   {B}BAĞLANTI UĞURLUDUR (ONLINE){' '*(27)} {W}║")
#         print(f"{G}║ {W}Merchant: {B}{MERCHANT_ID}{' '*(53 - len(MERCHANT_ID))} {W}║")
#     else:
#         print(f"{G}║ {R}STATUS:   AVTORİZASİYA XƏTASI (Merchant ID Yanlışdır!){W} ║")
    
#     print(f"{W}╠" + "═"*60 + "╣")
#     print_tree(json_data) # Gələn əlavə parametrlər varsa göstərilsin
#     print_footer()

#     if not is_valid:
#         return jsonify({"status": "error", "code": 1, "message": "Avtorizasiya səhvi"})

#     return jsonify({
#         "status": "success",
#         "code": 0,
#         "deviceInfo": {
#             "version": "v3.9",
#             "serialNumber": "AZ-SMART-888888",
#             "model": "SmartOne Cashbox"
#         }
#     })

@app.route('/check_status', methods=['POST'])
def check_status():
    is_valid, json_data = verify_and_decode(request.form)
    print_header("STATUS YOXLANIŞI (CHECK STATUS)")
    print(f"{G}║ {W}Zaman:  {B}{datetime.now().strftime('%H:%M:%S')}{' '*(41)} {W}║")
    print(f"{W}╠" + "═"*60 + "╣")
    print_tree(json_data)
    print_footer()
    return jsonify({
        "status": "success", "docStatus": 1, "fiscalID": "AZ-STATUS-OK",
        "fiscalNum": "SN-888", "qrCodeUrl": "https://monitoring.e-kassa.az/"
    })

@app.route('/check_copy', methods=['POST'])
def check_copy():
    print_header("ÇEK NÜSXƏSİ (COPY)")
    print(f"{G}║ {W}Mesaj:  {B}Nüsxə tələbi qəbul edildi.{' '*(30)} {W}║")
    print_footer()
    return jsonify({"status": "success", "message": "Nüsxə çap edilir..."})

if __name__ == '__main__':
    setup_terminal()
    print(f"{W}╔" + "═"*60 + "╗")
    print(f"║{G}       AZSMART VIRTUAL KASSA SERVER - VERSION 3.9 (Odoo 18){W}     ║")
    print(f"║{G}       PORT: {B}{PORT}{G} | MERCHANT: {B}{MERCHANT_ID}{G} | STATUS: {B}ONLINE{G}       {W}║")
    print(f"╚" + "═"*60 + "╝{RESET}")
    app.run(host='0.0.0.0', port=PORT, debug=False)