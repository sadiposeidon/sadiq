import requests
import json
import base64
import hashlib
from odoo import fields, models, api, _
from odoo.exceptions import UserError

class PosOrder(models.Model):
    _inherit = 'pos.order'

    azsmart_fiscal_id = fields.Char(string='Fiskal ID', readonly=True, copy=False)
    azsmart_check_no = fields.Char(string='Kassa Çek No', readonly=True, copy=False)
    azsmart_qr_url = fields.Char(string='QR URL', readonly=True, copy=False)
    azsmart_document_id = fields.Char(string='Kassa Sənəd ID', readonly=True, copy=False)
    
    @api.model
    def _order_fields(self, ui_order):
        res = super(PosOrder, self)._order_fields(ui_order)
        res.update({
            'azsmart_document_id': ui_order.get('azsmart_document_id', False),
            'azsmart_fiscal_id': ui_order.get('azsmart_fiscal_id', False),
            'azsmart_check_no': ui_order.get('azsmart_check_no', False),
            'azsmart_qr_url': ui_order.get('azsmart_qr_url', False),
        })
        return res

    def _prepare_azsmart_payload(self, data_dict):
        """API sənədinə uyğun data və imza hazırlayır"""
        config = self.session_id.config_id
        json_str = json.dumps(data_dict)
        encoded_data = base64.b64encode(json_str.encode('utf-8')).decode('utf-8')
        merchant_id = config.azsmart_merchant_id or "T12345X"
        
        raw_string = (encoded_data + merchant_id).encode('utf-8')
        sha1_hash = hashlib.sha1(raw_string).hexdigest().lower()
        signature = base64.b64encode(sha1_hash.encode('utf-8')).decode('utf-8')
        
        return encoded_data, signature

    def action_check_azsmart_status(self):
        """Terminaldan statusu sorğulayır"""
        self.ensure_one()
        doc_id = self.azsmart_document_id or self.azsmart_fiscal_id
        if not doc_id:
            raise UserError(_("Bu sifariş üçün AzSmart Sənəd ID tapılmadı."))

        config = self.session_id.config_id
        encoded_data, signature = self._prepare_azsmart_payload({"documentID": doc_id})
        url = f"http://{config.azsmart_device_ip}:{config.azsmart_device_port or '8008'}/check_status"
        
        try:
            response = requests.post(url, data={'data': encoded_data, 'sign': signature}, timeout=10)
            if response.status_code == 200:
                result = response.json()
                if result.get('status') == 'success':
                    self.write({
                        'azsmart_fiscal_id': result.get('fiscalID') or self.azsmart_fiscal_id,
                        'azsmart_check_no': result.get('fiscalNum') or self.azsmart_check_no,
                        'azsmart_qr_url': result.get('qrCodeUrl') or self.azsmart_qr_url,
                    })
                    return {'effect': {'fadeout': 'slow', 'message': 'Status yeniləndi!', 'type': 'rainbow_man'}}
                raise UserError(_("Terminal xətası: %s") % result.get('message', 'Uğursuz status'))
            raise UserError(_("HTTP Xətası: %s") % response.status_code)
        except Exception as e:
            raise UserError(_("Xəta: %s") % str(e))

    def action_reprint_azsmart_fiskal(self):
        """Çekin nüsxəsini çap edir"""
        self.ensure_one()
        if not self.azsmart_document_id:
            raise UserError(_("Sənəd ID yoxdur."))
            
        config = self.session_id.config_id
        encoded_data, signature = self._prepare_azsmart_payload({"documentID": self.azsmart_document_id})
        url = f"http://{config.azsmart_device_ip}:{config.azsmart_device_port or '8008'}/check_copy"
        
        try:
            requests.post(url, data={'data': encoded_data, 'sign': signature}, timeout=10)
            return {'effect': {'fadeout': 'slow', 'message': 'Nüsxə çapa göndərildi', 'type': 'rainbow_man'}}
        except Exception as e:
            raise UserError(str(e))

    def action_cancel_azsmart_fiskal(self):
        """Kassa sənədinin tam ləğv edilməsi (Refund)"""
        self.ensure_one()
        if not self.azsmart_document_id:
            raise UserError(_("Ləğv etmək üçün kassa sənəd ID-si tapılmadı."))
        
        config = self.session_id.config_id
        cancel_data = {
            "documentID": self.azsmart_document_id,
            "amount": abs(int(self.amount_total * 100)),
            "cashierName": self.user_id.name or "Admin"
        }
        
        encoded_data, signature = self._prepare_azsmart_payload(cancel_data)
        url = f"http://{config.azsmart_device_ip}:{config.azsmart_device_port or '8008'}/refund"
        
        try:
            response = requests.post(url, data={'data': encoded_data, 'sign': signature}, timeout=10)
            res = response.json()
            if res.get('status') == 'success':
                self.write({'azsmart_fiscal_id': (self.azsmart_fiscal_id or '') + ' (CANCELLED)'})
                return {'effect': {'fadeout': 'slow', 'message': 'Çek uğurla ləğv edildi!', 'type': 'rainbow_man'}}
            else:
                raise UserError(_("Kassa Xətası: %s") % res.get('message', 'Ləğv edilə bilmədi'))
        except Exception as e:
            raise UserError(_("Əlaqə xətası: %s") % str(e))

class PosSession(models.Model):
    _inherit = 'pos.session'

    def _loader_params_pos_order(self):
        res = super()._loader_params_pos_order()
        if res.get('search_params') and res['search_params'].get('fields'):
            res['search_params']['fields'].extend([
                'azsmart_fiscal_id', 
                'azsmart_check_no', 
                'azsmart_qr_url',
                'azsmart_document_id'
            ])
        return res