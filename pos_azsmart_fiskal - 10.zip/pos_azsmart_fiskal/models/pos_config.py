from odoo import fields, models

class PosConfig(models.Model):
    _inherit = 'pos.config'

    azsmart_active = fields.Boolean(string='AzSmart Aktivdir', default=True)
    azsmart_device_ip = fields.Char(string='AzSmart IP', default='127.0.0.1')
    azsmart_device_port = fields.Char(string='Port', default='8008')
    azsmart_merchant_id = fields.Char(string='Merchant ID', default='T12345X')

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    azsmart_active = fields.Boolean(related='pos_config_id.azsmart_active', readonly=False)
    azsmart_device_ip = fields.Char(related='pos_config_id.azsmart_device_ip', readonly=False)
    azsmart_device_port = fields.Char(related='pos_config_id.azsmart_device_port', readonly=False)
    azsmart_merchant_id = fields.Char(related='pos_config_id.azsmart_merchant_id', readonly=False)